import java.util.Scanner;
public class Subject extends Registration{
	private int subj_code;
	public Subject(){
		super();
	}
	public Subject(String name, int subj_code){
		super(name);
		this.subj_code = subj_code;
	}
	public void setsubj_code(int subj_code){
		this.subj_code = subj_code;
	}
	public int getsubj_code(){
		return subj_code;
	}
	public String toString(){
		return " the subject name is " + super.toString()+ " and their code is " +subj_code;
	}
	public static void main(String[] args) {
		Subject sub = new Subject();
		Scanner raya = new Scanner(System.in);
		System.out.println("please enter your subject name");
		sub.setname(raya.nextLine());
		System.out.println("enter your code subject");
		sub.setsubj_code(raya.nextInt());
		System.out.println(sub.toString());
	}
}