import java.util.Scanner;
public class Semester extends Registration{
	private int semes_number;
	public Semester(){
		super();
	}
	public Semester(String name, int semes_number){
		super(name);
		this.semes_number = semes_number;
	}
	public void setsemes_number(int semes_number){
		this.semes_number = semes_number;
	}
	public int getsemes_number(){
		return semes_number;
	}
	public String toString(){
		return " he/she learn at the Semester " +super.toString()+ " and semester number is " +semes_number;
	}
	public static void main(String[] args) {
		Semester sem = new Semester();
		Scanner raya = new Scanner(System.in);
		System.out.println("enter your Semester name");
		sem.setname(raya.nextLine());
		System.out.println("enter semester number");
		sem.setsemes_number(raya.nextInt());
		System.out.println(sem.toString());
	}
}