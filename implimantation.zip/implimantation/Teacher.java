import java.util.Scanner;
public class Teacher extends Registration{
	private int T_id;
	private int T_number;
	private String subj_name;
	private String email;
	public Teacher(){
		super();
	}
	public Teacher(String name, int T_id,int T_number, String subj_name, String email){
		super(name);
		this.T_id = T_id;
		this.T_number = T_number;
	}
	public void setT_id(int T_id){
		this.T_id = T_id;
	}
	public int getT_id(){
		return T_id;
	}
	public void setT_number(int T_number){
		this.T_number = T_number;
	}
	public int getT_number(){
		return T_number;
	}
	public void setsubj_name(String subj_name){
		this.subj_name = subj_name;
	}
	public String getsubj_name(){
		return subj_name;
	}
	public void setemail(String email){
		this.email = email;
	}
	public String email(){
		return email;
	}
	public String toString(){
		return " " +super.toString()+ " and his/her ID Number is" +T_id+ " the subject name is" +subj_name+ " with their email is " +email;
	}
	public static void main(String[] args) {
		Teacher tea = new Teacher();
		Scanner raya = new Scanner(System.in);
		System.out.println("please enter teacher name");
		tea.setname(raya.nextLine());
		System.out.println("please enter subject name that teacher teach student ");
		tea.setsubj_name(raya.nextLine());
		System.out.println("enter email");
		tea.setemail(raya.nextLine());
		System.out.println("please enter teacher ID");
		tea.setT_id(raya.nextInt());
		System.out.println("please enter teacher number");
		tea.setT_number(raya.nextInt());
		System.out.println(tea.toString());
	}

}