public class Registration{
	private String name;
	public Registration(){

	}
	public Registration(String name){
		this.name = name;
	}
	public void setname(String name){
		this.name = name;
	}
	public String getname(){
		return name;
	}
	public String toString(){
		return " " +name;
	}
}