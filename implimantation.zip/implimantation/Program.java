import java.util.Scanner;
public class Program extends Registration{
	private String NTA_level;
	private int Academicyear;
	public Program(){

	}
	public Program(String name, String NTA_level, int Academicyear){
		super(name);
		this.NTA_level = NTA_level;
		this.Academicyear = Academicyear;

	}
	public void setNTA_level(String NTA_level){
		this.NTA_level = NTA_level;
	}
	public String getNTA_level(){
		return NTA_level;
	}
	public void setAcademicyear(int Academicyear){
		this.Academicyear = Academicyear;
	}
	public int getAcademicyear(){
		return Academicyear;
	}
	public String toString(){
		return "the program is " +super.toString()+ " and NTA level is " +NTA_level+ " at the year" +Academicyear;
	}
	public static void main(String[] args) {
		Program tea = new Program();
		Scanner raya = new Scanner(System.in);
		System.out.println("please enter program name");
		tea.setname(raya.nextLine());
		System.out.println("please enter your level");
		tea.setNTA_level(raya.nextLine());
		System.out.println("please academic year");
		tea.setAcademicyear(raya.nextInt());
		System.out.println(tea.toString());
	}
}