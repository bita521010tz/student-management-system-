import java.util.Scanner;
public class Student extends Registration{
	private int std_id;
	private int phone;
	public Student(){

	}
	public Student(String name, int std_id, int phone){
		super(name);
		this.std_id = std_id;
		this.phone = phone;
	}
	public void setstd_id(int std_id){
		this.std_id = std_id;
	}
	public int getstd_id(){
		return std_id;
	}
	public void setphone(int phone){
		this.phone = phone;
	}
	public int getphone(){
		return phone;
	}
	public String toString(){
		return "the student name is " +getname()+ " and the ID Number is " +std_id+ " with phone Number is"+phone;
	}
	public static void main(String[] args) {
		Student std = new Student();
		Scanner raya = new Scanner(System.in);
		System.out.println("enter student name");
		std.setname(raya.nextLine());
		System.out.println("enter student id number");
		std.setstd_id(raya.nextInt());
		System.out.println("enter student phonr number");
		std.setphone(raya.nextInt());
		System.out.println(std.toString());

	}
}